function integer prova1 () 
    function f(integer num1, integer num2)
        float g
        float h
    end 
    float f = 3
    float k = 5

    if k == 5 then
        
        f = 3+2
        boolean f 
        f = true
        function boolean f(integer num1, integer num2)
            integer i
            return true
        end   
    end

    return 0
end

--[commento di prova

function boolean prova2 (integer num, integer dim)
    integer i = 0
    while i < dim do
        if  i == 0 then 
            return false
        end
        i++
    end
    return true
end